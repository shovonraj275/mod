
function opneNav(){
    document.getElementById("mobileNav").style.width ="100%"
  }
  
  function closeNav(){
    document.getElementById("mobileNav").style.width ="0%"
  }
  